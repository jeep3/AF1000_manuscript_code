# 加载必要的R包
library(ggplot2)            # 用于数据可视化绘图
library(dplyr)              # 用于数据操作和转换
library(readxl)             # 用于读取Excel文件
library(sf)                 # 用于处理空间矢量数据
library(ggspatial)          # 用于地图标注（比例尺、指北针）
library(rnaturalearth)      # 用于获取世界地图数据
library(rnaturalearthdata)  # rnaturalearth的配套数据包

# 获取世界地图数据 (包括周边国家)
#world <- ne_countries(scale = "medium", returnclass = "sf")  # 获取世界国家数据，返回sf格式

# 读取中国省级分区数据
china_province <- st_read("china_province.geojson", quiet = TRUE) %>%   
  st_make_valid() %>%                 
  st_transform(4326)

# 读取气候区划数据 (Climate_quhua.shp)
climate_zones <- st_read("D:/Rdata/china_map/quhua/Climate_quhua/Climate_quhua.shp", quiet = TRUE) %>%
  st_make_valid() %>%
  st_transform(4326)

# 检查气候区划数据中的name列的唯一值
unique(climate_zones$code1)

# 将code1列转换为因子
climate_zones$code1 <- as.factor(climate_zones$code1)

# 根据一级气候区划（`code1`）为每个气候区设置颜色
climate_colors <- c("1" = "#fee0d2",  # 北温带
                    "2" = "#e5f5e0",  # 中温带
                    "3" = "#c7e9c0",  # 南温带
                    "4" = "#a1d99b",  # 北亚热带
                    "5" = "#74c476",  # 中亚热带
                    "6" = "#41ab5d",  # 南亚热带
                    "7" = "#238b45",  # 北热带
                    "8" = "#006d2c",  # 中热带
                    "10" = "#dadaeb")  # 高原气候区

# 基础地图绘制，显示中国及其周边国家
p1 <- ggplot() +
  #geom_sf(data = world, fill = "white", color = "grey60", size = 0.2) +  # 绘制世界地图（包括周边国家）
  geom_sf(data = china_province, fill = "white", color = "grey60") +     # 绘制中国省份边界
  geom_sf(data = climate_zones, aes(fill = code1), color = "grey80", alpha = 0.9) +  # 使用一级区划的code1
  coord_sf(crs = 4326, xlim = c(85, 135), ylim = c(5, 55)) +  # 设置地图范围，显示中国及其周边国家
  scale_fill_manual(values = climate_colors) +  # 设置一级气候区划的颜色填充
  theme_minimal() + 
  theme(panel.background = element_rect(fill = "#d1eefc"), 
        panel.grid = element_blank(),
        legend.position = "right")

# 读取样本数据 (data3.xlsx)
data <- read_excel("data3.xlsx")

# 转换为sf对象
data_sf <- st_as_sf(data, coords = c("longitude", "latitude"), crs = 4326)

# 添加样本点，根据Value值展示样本大小
p2 <- p1 + 
  geom_sf(data = data_sf, aes(size = Value), color = "#3182bd", fill = "#636363", shape = 16) +  # 使用 fill 和 color 设置样本点的颜色为深蓝色
  scale_size_continuous(name = "Sample Size", range = c(1, 10)) +  # 根据Value值调节点的大小
  theme(legend.position = "right")  # 图例显示在右边

# 添加指北针和比例尺
p3 <- p2 +
  annotation_north_arrow(location = "tl", which_north = TRUE,  
                         height = unit(1, "cm"), width = unit(1, "cm"),
                         style = north_arrow_fancy_orienteering) +  # 指北针样式
  annotation_scale(location = "bl", width_hint = 0.3)  # 比例尺

# 创建南海九段线区域的缩略图
# 我们通过设置xlim和ylim来显示南海区域，并将其大小适当调整
p4 <- ggplot() +
  geom_sf(data = china_province, fill = "white", color = "grey60") +  # 绘制中国省份边界
  geom_sf(data = climate_zones, aes(fill = code1), color = "grey80", alpha = 0.9) +  # 使用一级区划的code1
  coord_sf(crs = 4326, xlim = c(105, 125), ylim = c(4, 20)) +  # 设置南海九段线区域的xlim和ylim
  scale_fill_manual(values = climate_colors) +  # 设置一级气候区划的颜色填充
  theme_minimal() + 
  theme(panel.background = element_rect(fill = "white"), 
        panel.grid = element_blank(),
        legend.position = "none")  # 不显示缩略图的图例

# 在主地图中添加南海九段线区域缩略图
p_final <- p3 +
  annotation_custom(
    grob = ggplotGrob(p4),                   # 将缩略图转换为图形对象
    xmin = 1600, xmax = 2520,                # 设置插图在主图中的位置和大小（x方向）
    ymin = -2160, ymax = -1000               # 设置插图在主图中的位置和大小（y方向）
  )

# 显示最终地图
print(p_final)

# 保存地图
ggsave("china_map_with_samples_and_inset.pdf", plot = p_final, height = 6, width = 10)
