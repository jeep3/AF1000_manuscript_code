# Load necessary R packages
library(ggplot2)            # For data visualization and plotting
library(dplyr)              # For data manipulation and transformation
library(readxl)             # For reading Excel files
library(sf)                 # For handling spatial vector data
library(ggspatial)          # For adding map annotations (scale, north arrow)
library(rnaturalearth)      # For obtaining world map data
library(rnaturalearthdata)  # For additional datasets from rnaturalearth

# Read in the China provincial boundary data (GeoJSON format)
china_province <- st_read("china_province.geojson", quiet = TRUE) %>%   
  st_make_valid() %>%                 # Ensure the geometries are valid
  st_transform(4326)                  # Reproject to the WGS84 coordinate system (EPSG:4326)

# Read in climate zoning data (Shapefile format)
climate_zones <- st_read("D:/Rdata/china_map/quhua/Climate_quhua/Climate_quhua.shp", quiet = TRUE) %>%
  st_make_valid() %>%                 # Ensure the geometries are valid
  st_transform(4326)                  # Reproject to the WGS84 coordinate system

# Check unique values in the 'code1' column of the climate zone data
unique(climate_zones$code1)

# Convert 'code1' column to a factor (to use for mapping colors)
climate_zones$code1 <- as.factor(climate_zones$code1)

# Set color palette for climate zones based on 'code1' values
climate_colors <- c("1" = "#fee0d2",  # Temperate Zone (North)
                    "2" = "#e5f5e0",  # Temperate Zone (Central)
                    "3" = "#c7e9c0",  # Temperate Zone (South)
                    "4" = "#a1d99b",  # Subtropical Zone (North)
                    "5" = "#74c476",  # Subtropical Zone (Central)
                    "6" = "#41ab5d",  # Subtropical Zone (South)
                    "7" = "#238b45",  # Tropical Zone (North)
                    "8" = "#006d2c",  # Tropical Zone (Central)
                    "10" = "#dadaeb")  # Plateau Climate Zone

# Create the base map displaying China and surrounding countries
p1 <- ggplot() +
  #geom_sf(data = world, fill = "white", color = "grey60", size = 0.2) +  # World map (commented out)
  geom_sf(data = china_province, fill = "white", color = "grey60") +     # Draw China provinces boundary
  geom_sf(data = climate_zones, aes(fill = code1), color = "grey80", alpha = 0.9) +  # Use 'code1' for color fill
  coord_sf(crs = 4326, xlim = c(85, 135), ylim = c(5, 55)) +  # Set the map extent to show China and its surroundings
  scale_fill_manual(values = climate_colors) +  # Set the color fill for climate zones
  theme_minimal() +  # Use a minimal theme
  theme(panel.background = element_rect(fill = "#d1eefc"),  # Set the background color of the panel
        panel.grid = element_blank(),  # Remove grid lines
        legend.position = "right")  # Place the legend on the right

# Read in the sample data from an Excel file
data <- read_excel("data3.xlsx")

# Convert the sample data into an 'sf' object for spatial plotting
data_sf <- st_as_sf(data, coords = c("longitude", "latitude"), crs = 4326)

# Create a map with sample points, sized based on 'Value' column
p2 <- p1 + 
  geom_sf(data = data_sf, aes(size = Value), color = "#3182bd", fill = "#636363", shape = 16) +  # Use 'fill' and 'color' to set sample points' color (blue)
  scale_size_continuous(name = "Sample Size", range = c(1, 10)) +  # Scale point size based on 'Value'
  theme(legend.position = "right")  # Place the legend on the right side

# Add a north arrow and scale bar to the map
p3 <- p2 +
  annotation_north_arrow(location = "tl", which_north = TRUE,  
                         height = unit(1, "cm"), width = unit(1, "cm"),
                         style = north_arrow_fancy_orienteering) +  # Fancy north arrow style
  annotation_scale(location = "bl", width_hint = 0.3)  # Add scale bar at the bottom-left

# Create an inset map for the South China Sea (using specific xlim and ylim)
p4 <- ggplot() +
  geom_sf(data = china_province, fill = "white", color = "grey60") +  # Draw China provinces boundary
  geom_sf(data = climate_zones, aes(fill = code1), color = "grey80", alpha = 0.9) +  # Use 'code1' for color fill
  coord_sf(crs = 4326, xlim = c(105, 125), ylim = c(4, 20)) +  # Set extent for the South China Sea region
  scale_fill_manual(values = climate_colors) +  # Set the color fill for climate zones
  theme_minimal() +  # Use minimal theme
  theme(panel.background = element_rect(fill = "white"),  # White background for the inset map
        panel.grid = element_blank(),  # Remove grid lines from the inset map
        legend.position = "none")  # Hide the legend for the inset map

# Add the inset map (South China Sea) to the main map
p_final <- p3 +
  annotation_custom(
    grob = ggplotGrob(p4),                   # Convert the inset map to a grob (graphical object)
    xmin = 1600, xmax = 2520,                # Set position of the inset map on the main map (x-axis)
    ymin = -2160, ymax = -1000               # Set position of the inset map on the main map (y-axis)
  )

# Display the final map
print(p_final)

# Save the final map as a PDF file
ggsave("china_map_with_samples_and_inset.pdf", plot = p_final, height = 6, width = 10)
